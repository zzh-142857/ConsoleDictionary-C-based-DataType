#ConsoleDictionary&C-based DataType#

>This project is program beginner's practice.


###Project Introduction
This project is mainly a C header file of self-made data type extension, witch includes liking list, circle liking list and binary tree. To use such header, I created a console application which serve as a dictionary. It can be manipulated by commands and operate files. The suffix ".dtn" is used to declare a text file of readable formmat.A few dtn files has been included to show the application's function.


###Uploader's Words
This project is my first afterclass project, when I've finished reading The Brief Introduction of Conputer Science textbook.

Having learned binary tree from a case in the book, I decided to code a dictionary program based on binary tree, and write some linking list functions at the same project. Although at that time I used to know little object-oriented programming methods and I could only write it by pure C, I managed to get this done.

As expected, this project soon became useless because of its limits. Nevertheless, it's my first open source project after all.