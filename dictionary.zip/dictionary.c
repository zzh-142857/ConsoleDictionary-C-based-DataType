#include<stdio.h>
#include<string.h>
#include"biTree.h"
/*
дһ���ֵ�С������Ҫ�����ݷ���Ĳ������Ѿ�д�÷Ž�ͷ�ļ��ˣ����Կ����ڸ߲�εĳ���ʼд
���ߵ������װ��������ǿ�ʼд��������ʱ�����Ѿ�ɵ��233333
�����ֵ��õ��ĺ���ȷʵ���ṩ���٣���Ȼ��������bug�����ո�һ��
дһ������ָ��������������ֵ�
��ָ�� �������
/new                     use dictionary without opening anything
/open   [Path]           open a dictionary file
/augm   [Path]           add from a dictionary file to current loaded dictionary
/save   [Path]           save a dictionary file
/exit                    as we all know...
/add    [Info] [Content] add a word, then follow its content with a space, if the word exist, this will change its content, if not exist,this will be added to current dictionary
/remove [Info]           remove an item from current dictionary
/help                    the instruction for you when you don't know how to use other instructions (nonsense)
*/
int main(int argc,char *argv[],char* envp[])
{
    char instruction[1024]={0},header[8]={0},usable=0;
    bTree tree=0;
    puts("Open a prebuild file or create a new file for word mapping");
    gets(instruction);
    strncpy(header,instruction,6);
    while(strcmp(header,"/exit")&&strcmp(header,"/exit ")){
        strncpy(header,instruction,5);
        header[5]=0;
        if(instruction[0]!='/'){
            if(usable){
                char targetInfo[64]={0};
                for(int i=0;instruction[i]!=' '&&instruction[i]!='\n'&&i<64;i++)
                    targetInfo[i]=instruction[i];
                bTree target=search(targetInfo,tree);
                if(target) printf("%s:%s\n",target->info,target->cntn);
                else printf("could not find \"%s\"\n",targetInfo);
            }
            else puts("You may input /help for a brief guidance.");
        }
        else{
            if(!strcmp(header,"/new")||!strcmp(header,"/new ")){
                usable=1;
                printf("[New File:\\]\n");
            }
            else if(!strcmp(header,"/add")||!strcmp(header,"/add ")){
                if(usable){
                    int i=0,j=0;
                    while(instruction[i++]!=32);
                    while(instruction[i]==32) i++;
                    char info[64]={0};
                    while(instruction[i]!=32&&instruction[i]!=10&&j<63)
                        info[j++]=instruction[i++];
                    while(instruction[i]==32) i++;
                    printf("[add:info=%s]\n",info);
                    bTree cursor=branch(info,tree);
                    if(!tree) tree=cursor;
                    if(instruction[i]!='\n'){
                        j=0;
                        char cntn[944]={0};
                        while(instruction[i]!=10&&j<943)
                            cntn[j++]=instruction[i++];
                        load944(cursor->cntn,cntn);
                    }
                }
                else puts("[No available file]");
            }
            else{
                strncpy(header,instruction,6);
                header[6]=0;
                if(!strcmp(header,"/open")||!strcmp(header,"/open ")){
                    int i=0;
                    while(instruction[i++]!=32);
                    while(instruction[i]==32) i++;
                    char path[512]={0};
                    strcpy(path,instruction+i);
                    //printf("%s",path);
                    FILE* fp=fopen(path,"r");
                    tree=newBTreeB(fp);
                    printf("[%s:\\\\]\n",path);
                    fclose(fp);
                    usable=1;
                }
                else if(!strcmp(header,"/augm")||!strcmp(header,"/augm ")){
                    int i=0;
                    while(instruction[i++]!=32);
                    while(instruction[i]==32) i++;
                    char path[512]={0};
                    strcpy(path,instruction+i);
                    //printf("%s",path);
                    FILE*fp=fopen(path,"r");
                    tree=grow(fp,tree);
                    printf("[augment:%s:\\\\]\n",path);
                    fclose(fp);
                    usable=1;
                }
                else if(!strcmp(header,"/save")||!strcmp(header,"/save ")){
                    if(usable){
                        int i=0;
                        while(instruction[i++]!=32);
                        while(instruction[i]==32) i++;
                        char path[512]={0};
                        strcpy(path,instruction+i);
                        printf("path=%s\n",path);
                        FILE*fp=fopen(path,"w");
                        int count=0;
                        fprintB(fp,&count,tree);
                        printf("[saved to %s]\n",path);
                        fclose(fp);
                    }
                    else puts("[No available file]");
                }
                else if(!strcmp(header,"/help")||!strcmp(header,"/help ")){
                    puts("--------------------------------------------------------------------------------------------------------------------");
                    printf("directly input an existent word to access according content\xa");
                    puts("/new                       use dictionary without opening anything");
                    puts("/help                      the instruction for you when you don't know how to use other instructions (nonsense)");
                    puts("/open   [Path]             open a dictionary file");
                    puts("/augm   [Path]             add from a dictionary file to current loaded dictionary,\n\t\t\t   any item defined in previous file won't be override");
                    puts("/save   [Path]             save a dictionary file, without override warning");
                    puts("/exit                      as we all know...");
                    puts("/add    [Info] [Content]   add a word, then follow its content with a space, if exist, this will change its content,\n\t\t\t   if not exist,this will be added to current dictionary");
                    puts("/remove [Info]             remove an item from current dictionary");  //1 Tap== 8 space
                    puts("--------------------------------------------------------------------------------------------------------------------");
                }
                else{
                    strncpy(header,instruction,8);
                    header[8]=0;
                    if(!strcmp(header,"/remove")||!strcmp(header,"/remove ")){
                        if(usable){
                                int i=0,j=0;
                                while(instruction[i++]!=32);
                                while(instruction[i]==32) i++;
                                char info[64]={0};
                                while(instruction[i]!=10&&j<63)
                                    info[j++]=instruction[i++];
                                tree=vanish(info,tree);
                        }
                        else puts("[No available file]");
                    }
                    else puts("You may input /help for a brief guidance.");
                }
            }
        }
        //printB(tree);
        gets(instruction);
        strncpy(header,instruction,6);
    }
    return 0;
}
